import eventlet
eventlet.monkey_patch()

from application import application, socketio

if __name__ == "__main__":
    socketio.run(application) 