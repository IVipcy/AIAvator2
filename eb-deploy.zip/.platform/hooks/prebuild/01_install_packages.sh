#!/bin/bash

echo "Installing Python dependencies..."
source /var/app/venv/*/bin/activate
pip install --upgrade pip
pip install -r /var/app/staging/requirements.txt --no-cache-dir
echo "Python dependencies installed successfully" 